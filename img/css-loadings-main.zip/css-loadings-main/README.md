# CSS Loading Animation
Loading Animation Created With Pure CSS
![Screenshot](https://raw.githubusercontent.com/zuramai/css-loadings/main/screenshot.png)
